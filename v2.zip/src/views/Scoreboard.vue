<template>
  <div class="scoreboard-view">
      this is scoreboard
      {{ $route.params.cid}}
  </div>
</template>

<script>
export default {
    name: "scoreboard"
}
</script>

<style>

</style>