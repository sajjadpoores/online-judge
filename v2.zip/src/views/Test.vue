<template>
  <div class="test">
      <Nav />
      <!-- <Rmenu /> -->
  </div>
</template>

<script>
import Nav from '../components/Nav.vue'
// import Rmenu from '../components/Rmenu.vue'
import Profile from '../views/Profile.vue'
export default {
    name: "Test",
    components: { Nav},
}
</script>

<style>

</style>  